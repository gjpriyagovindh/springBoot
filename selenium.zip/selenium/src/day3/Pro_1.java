package day3;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Pro_1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Thread.sleep(3000);
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(2));
		driver.navigate().to("https://www.geeksforgeeks.org/");
		
		//Thread.sleep(3000);
		driver.manage().window().maximize();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
		.withTimeout(Duration.ofSeconds(30))
		.pollingEvery(Duration.ofSeconds(5))
				  .ignoring(NoSuchElementException.class);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebDriverWait wait1 = new WebDriverWait(driver,Duration.ofSeconds(10));
		WebDriverWait wait2 = new WebDriverWait(driver,Duration.ofSeconds(5));
		wait1.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("userProfileId")))).click();
		//Thread.sleep(3000);
		wait1.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("luser")))).sendKeys("priyadharshini73055@gmail.com");
		wait2.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.name("pass")))).sendKeys("Eunwoo490v");
		//Thread.sleep(3000);
		wait2.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.className("signin-button")))).click();
		//Thread.sleep(3000);
		
		
	}

}
