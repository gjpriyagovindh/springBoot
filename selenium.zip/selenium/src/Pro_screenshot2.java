import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;


public class Pro_screenshot2 {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.google.com/search?q=bts+members&rlz=1C1ONGR_enIN1065IN1065&oq=bts&aqs=chrome.5.0i271j46i433i512j35i39i650j0i433i512j46i433i512j0i433i512l2j69i60.4062j0j7&sourceid=chrome&ie=UTF-8");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		File src =((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("./image.png"));

	}

}
