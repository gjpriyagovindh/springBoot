package day1selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pro_q1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.oyorooms.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement button =driver.findElement(By.className("datePickerDesktop__checkInOutText"));
		button.click();
		Thread.sleep(3000);
		WebElement button1 =driver.findElement(By.className("DateRangePicker__PaginationArrow--next"));
		button1.click();
		Thread.sleep(3000);
		WebElement button2 =driver.findElement(By.className("DateRangePicker__PaginationArrowIcon--next"));
		button2.click();
		Thread.sleep(3000);
		WebElement button3 =driver.findElement(By.className("DateRangePicker__PaginationArrowIcon--next"));
		button3.click();
		Thread.sleep(3000);
		List<WebElement> arr = driver.findElements(By.className("DateRangePicker__DateLabel"));
		for (WebElement d:arr) {
			if (d.getText().equals("2")|| d.getText().equals("3")) {
				{
					d.click();
					Thread.sleep(3000);
					
					if (d.getText().equals("3")) 
						break;
				}
				
		
		
		

	}

		}}}
