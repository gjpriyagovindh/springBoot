package day1selenium;

import org.openqa.selenium.chrome.ChromeDriver;

public class Twitter {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://twitter.com/i/flow/login?redirect_after_login=%2Flogin%3Flang%3Den");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);

	}

}
