package day1selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program5_fb_locator {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement emailBox =driver.findElement(By.id("email"));
		emailBox.sendKeys("abc@gmail.com");
		Thread.sleep(2000);
		WebElement passwordBox =driver.findElement(By.id("pass"));
		passwordBox.sendKeys("123456");
		Thread.sleep(2000);
		WebElement button =driver.findElement(By.name("login"));
		button.click();
		//WebElement fp =driver.findElement(By.partialLinkText("pass"));
		//fp.click();
		
		List<WebElement>tags =driver.findElements(By.tagName("input"));
		System.out.println(tags.size());

}
}
