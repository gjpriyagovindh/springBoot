package day1selenium;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program_6 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
				System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
				ChromeDriver driver = new ChromeDriver();
				Thread.sleep(3000);
				driver.navigate().to("https://itera-qa.azurewebsites.net/home/automation");
				Thread.sleep(3000);
				driver.manage().window().maximize();
				Thread.sleep(3000);
				WebElement nameBox =driver.findElement(By.id("name"));
				nameBox.sendKeys("selenium");
				Thread.sleep(3000);
				WebElement noBox =driver.findElement(By.id("phone"));
				noBox.sendKeys("1234567890");
				Thread.sleep(3000);
				WebElement mailBox =driver.findElement(By.id("email"));
				mailBox.sendKeys("abc@gmail.com");
				Thread.sleep(3000);
				WebElement pwdBox =driver.findElement(By.id("password"));
				pwdBox.sendKeys("12345");
				Thread.sleep(3000);
				WebElement adBox =driver.findElement(By.id("address"));
				adBox.sendKeys("verizon,chennai");
				Thread.sleep(3000);
				WebElement button =driver.findElement(By.name("submit"));
				button.click();
				Thread.sleep(3000);
				WebElement button1 =driver.findElement(By.id("male"));
				button1.click();
				Thread.sleep(3000);
				
				List<WebElement> arr = driver.findElements(By.tagName("input"));
				for (int i=0; i<=arr.size() ; i++) {
					if (i==8|| i==11 || i==14) {
						(arr.get(i)).click();
						Thread.sleep(3000);
						if (i == 14)
							break;
						
					}
					
				}
					
	}

}
				 
				
			   
			   

			
			   

				

