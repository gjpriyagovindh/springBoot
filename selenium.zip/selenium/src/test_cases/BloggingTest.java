package test_cases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class BloggingTest {
	
	WebDriver driver = new ChromeDriver();
	@Test
	void geekforgeeks() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		Thread.sleep(3000);
		driver.navigate().to("https://www.geeksforgeeks.org/");
		Thread.sleep(3000);
		//driver.manage().window().maximize();
		//Thread.sleep(3000);
		
	}
	@Test
	void w3schools() throws InterruptedException
	{
		driver.navigate().to("https://www.w3schools.com/");
		Thread.sleep(3000);
		//driver.manage().window().maximize();
		//Thread.sleep(3000);
		
	}
	
	@Test
	void guru99() throws InterruptedException
	{
		driver.navigate().to("https://www.guru99.com/");
		Thread.sleep(3000);
		//driver.manage().window().maximize();
		//Thread.sleep(3000);
		driver.close();
	}
	}


