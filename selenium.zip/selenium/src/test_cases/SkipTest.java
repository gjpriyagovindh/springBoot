package test_cases;

import org.testng.annotations.Test;

public class SkipTest {
	
	@Test
	void login()
	{
		System.out.println("log in");
		int num =10/0;
	}
	
	@Test(dependsOnMethods="login")
	void logout()
	{
		System.out.println("logout");
	}

}
