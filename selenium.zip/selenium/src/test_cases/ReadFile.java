package test_cases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream fis = new FileInputStream("C:\\Users\\DELL\\eclipse-workspace\\selenium\\src\\test_cases\\data.properties");
		Properties prop =new Properties() ; 
		prop.load(fis);
		System.out.println(prop.getProperty("url"));

	}

}
