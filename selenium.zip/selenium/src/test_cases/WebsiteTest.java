package test_cases;

import org.testng.annotations.*;

public class WebsiteTest {
	
	
	@BeforeSuite
	void beforeSuite()
	{
		System.out.println("Before Suite");
	} 
	@AfterSuite
	void afterSuite()
	{
		System.out.println("after Suite");
	} 
	
	@BeforeClass
	void beforeclass2()
	{
		System.out.println("before class2");
	} 
	@AfterClass
	void afterclass2()
	{
		System.out.println("after class2");
	} 
	
	@BeforeMethod
	void beforemethod2()
	{
		System.out.println("before method2");
	} 
	
	@AfterMethod
	void aftermethod2()
	{
		System.out.println("after method2");
	} 
	@Parameters({"username"})
	@Test(groups="loginTest")//(enabled=false)
	void login(String u)
	{
		System.out.println("website login" + u);
	}
    
	@Test(dataProvider="getData")
	void logout(String username, String password)
	{
		System.out.println("website logout"+ username +" " +password);
	}
	
	
	
	@DataProvider
	Object[][] getData()
	
	
	{
		Object[][]data = new Object[3][2];
		data[0][0]= "user1";
		data[0][1]= "user2";
		data[1][0]= "user3";
		data[1][1]= "user4";
		data[2][0]= "user5";
		data[2][1]= "user6";
		return data;
		
		
	}
}
