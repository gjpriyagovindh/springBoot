package test_cases;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AsMakeMyTrip {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.makemytrip.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		//driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]/div[1]/ul/li[4]")).click();
		//Thread.sleep(3000);
		driver.findElement(By.id("username")).sendKeys("8072118824");

		driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]/div[2]/div[2]/div/section/form/div[2]/button")).click();
		Thread.sleep(3000);
		driver.findElement(By.className("capText font16")).click();
		driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]/div[2]/div[2]/div/section/form/div[1]/div/input")).click();
		Thread.sleep(3000);
		Scanner otp = new Scanner(System.in);
		System.out.println("Enter the otp");
		String sc = otp.nextLine();
		WebElement ot = driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]/div[2]/div[2]/div/section/form/div[1]/div/input"));
		ot.sendKeys(sc);
		JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript("document.elementFromPoint(0,0).click()");



	}

}
