package test_cases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class MobileTest {
	
	
	
	@BeforeClass
	void beforeclass1()
	{
		System.out.println("before class 1");
	} 
	@AfterClass
	void afterclass1()
	{
		System.out.println("after class 1");
	} 
	
	@BeforeMethod
	void beforemethod1()
	{
		System.out.println("before method 1");
	} 
	
	@AfterMethod
	void aftermethod1()
	{
		System.out.println("after method 1");
	} 
	
	
	@Test
	void login()
	{
		
		try {
		System.out.println("Mobile Login");
		//int num = 10/0;
	}
		catch(Exception ex) {
			System.out.println("there is an exeption");
		}
			
		}
	
	@Test
	
	void logout()
	{
		System.out.println("mobile logout");
		
	}
	
	

	
}
