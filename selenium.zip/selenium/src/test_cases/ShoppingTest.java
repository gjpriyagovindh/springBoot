package test_cases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ShoppingTest {
	WebDriver driver = new ChromeDriver();
	@Test
	void amazon() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		Thread.sleep(3000);
		driver.navigate().to("https://www.amazon.in/");
		Thread.sleep(3000);
		//river.manage().window().maximize();
		//Thread.sleep(3000);
		

}
	@Test
	void flipcart() throws InterruptedException
	{
		driver.navigate().to("https://www.flipkart.com/");
		Thread.sleep(3000);
		//driver.manage().window().maximize();
		//Thread.sleep(3000);
		driver.close();
	}
	
	
}
