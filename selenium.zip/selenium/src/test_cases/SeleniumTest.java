package test_cases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class SeleniumTest {
	
	WebDriver driver = new ChromeDriver();
	@BeforeMethod
	void setuP() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		Thread.sleep(3000);
	}
	
	@Test
	void test() throws InterruptedException
	{
		driver.get("https://en.wikipedia.org/wiki/BTS");
		Thread.sleep(3000);
		driver.manage().window().maximize();
	}
	
	@AfterMethod
	void tearDown()
	{
		driver.close();
	}
	
	
	

}
