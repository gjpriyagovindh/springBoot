package day2;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pro_Winhandle {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://the-internet.herokuapp.com/windows");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.linkText("Click Here")).click();
		Set<String> w = driver.getWindowHandles();
		Iterator<String> it = w.iterator(); 
		String p = it.next();
		Thread.sleep(3000);
		String c = it.next();
		driver.switchTo().window(p);
		Thread.sleep(3000);
		driver.switchTo().window(c);
		Thread.sleep(3000);
		driver.close();
		driver.switchTo().window(p);
		Thread.sleep(3000);
		driver.close();
		
		
		
		

	}

}
