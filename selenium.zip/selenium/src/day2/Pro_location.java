package day2;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Pro_location {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_setting_values.notifications", 2);// 0,MINUS NO - ALLOW , 1,2 - ACCEPT , 
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
	
		Thread.sleep(3000);
		WebDriver driver = new ChromeDriver(options);
		Thread.sleep(3000);

		driver.navigate().to("https://www.spicejet.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);

	}

}
