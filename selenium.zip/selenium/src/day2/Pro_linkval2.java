package day2;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pro_linkval2 {

	public static void main(String[] args) throws InterruptedException, IOException, Exception {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		List<WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println(links.size());
		for (WebElement e :links)
		 {
			System.out.println(e.getText()+" ");
			HttpURLConnection conn = (HttpURLConnection) new URL(e.getAttribute("href"))
					.openConnection();
			conn.setRequestMethod("GET");
			conn.connect();
			if(conn.getResponseCode()==200)
				{
				System.out.println("working");
				}
			else
					{
				System.out.println(" not working");
					};
			
		 }

	}

	
}
