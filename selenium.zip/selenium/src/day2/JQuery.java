package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class JQuery {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://jqueryui.com/droppable/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,50)");
		WebElement frame =driver.findElement(By.className("demo-frame"));
		driver.switchTo().frame(frame);
		Actions act =new Actions(driver);
		
		WebElement fr1 =driver.findElement(By.xpath("//*[@id=\"draggable\"]"));
		WebElement fr2 =driver.findElement(By.xpath("//*[@id=\"droppable\"]"));
		act.dragAndDrop(fr1, fr2).build().perform();

	}

}
