package day2;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Pro_linkValidation {

	public static void main(String[] args) throws MalformedURLException, IOException {
		// TODO Auto-generated method stub
		
		HttpURLConnection conn = (HttpURLConnection) new URL ("https://www.facebook.com/")
				.openConnection();
		conn.setRequestMethod("Get");
		conn.connect();
		System.out.println(conn.getResponseCode());
		

	}

}
