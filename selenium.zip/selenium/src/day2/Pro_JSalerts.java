package day2;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pro_JSalerts {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://the-internet.herokuapp.com/javascript_alerts");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[text()='Click for JS Alert']")).click();
		Thread.sleep(3000);
		Alert aw =driver.switchTo().alert();
		System.out.println(aw.getText());
		aw.accept();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[text()='Click for JS Confirm']")).click();
		Thread.sleep(3000);
		Alert aw1 =driver.switchTo().alert();
		System.out.println(aw1.getText());
		aw1.dismiss();
		driver.findElement(By.xpath("//*[text()='Click for JS Prompt']")).click();
		Thread.sleep(3000);
		Alert aw2 =driver.switchTo().alert();
		System.out.println(aw2.getText());
		aw2.sendKeys("hi");
		Thread.sleep(3000);
		aw2.accept();
		

}
}
