package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Action {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.amazon.in/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		/*WebElement signin =driver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]"));
		*Actions act =new Actions(driver);
		*act.moveToElement(signin).build().perform();*/
		Actions act =new Actions(driver);
		WebElement input =driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));
		act.keyDown(Keys.SHIFT).build().perform();
		input.sendKeys("hello");
		act.keyUp(Keys.SHIFT).build().perform();
		input.sendKeys("bye");
		
		
		
		

	}

}
