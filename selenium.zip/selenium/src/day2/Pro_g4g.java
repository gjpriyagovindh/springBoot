package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pro_g4g {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\testing\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.geeksforgeeks.org/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.id("userProfileId")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("luser")).sendKeys("priyadharshini73055@gmail.com");
		Thread.sleep(3000);
		driver.findElement(By.name("pass")).sendKeys("Eunwoo490v");
		Thread.sleep(3000);
		driver.findElement(By.className("signin-button")).click();
		Thread.sleep(3000);
		//driver.findElement(By.id("recaptcha-anchor-label")).();



	}

}
