package enterprise;

public class EnterpriseConfig {

}
