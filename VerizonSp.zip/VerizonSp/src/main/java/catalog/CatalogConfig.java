package catalog;

public class CatalogConfig {

}
