package consumerOrder;

public class ConsumerOrderConfig {

}
