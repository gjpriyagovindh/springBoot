package com;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.example.Order;
import com.example.OrderConfig;

import config.EmployeeConfig;
import data.Employee;

@SpringBootApplication
public class Application {

public static void main(String[] args) {
       ApplicationContext context= new AnnotationConfigApplicationContext(OrderConfig.class);
       SpringApplication.run(Application.class, args);
       Order employee= context.getBean("employeeBean", Order.class);
       employee.test;
}

}

