package com.example;

public class Order {
	private int OrderId;
	private String name;
	
	public int getOrderId()
	{
		return this.OrderId;
	}
	public String getName()
	{
		return this.name;
	}
	public void setOrderId(int num)
	{
		this.OrderId=num;
	}
	public void setName(String n)
	{
		this.name=n;
	}

}
